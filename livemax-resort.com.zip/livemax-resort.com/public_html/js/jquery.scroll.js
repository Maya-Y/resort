/*ページスクロール*/
$(function() {
	$(".scroll").click(function(event){
		event.preventDefault();
				
		var url = this.href;
	
		var parts = url.split("#");
		var target = parts[1];
		 
		var target_offset = $("#"+target).offset();
		var target_top = target_offset.top;
		 
		$('html, body').animate({scrollTop:target_top}, 700);
 	});
});

// 別ページ遷移後スクロール
function page_jump( ids ) {
	var navi = $( ids ).attr( "href" );						// 受け取った引数を使ってidを特定、リンク先hrefを取得
	var string = navi.split( '#' );							// リンク先hrefを#で分割
	var for_href = string[0] + "?" + string[1];		// #の変わりに?を入れて引数付きのリンクに整形
	location.href = for_href;								// ジャンプ
	return false;
}
function link_navi() {
	if ( location.href.indexOf( '?' ) == -1 ){			// location.hrefに?が含まれているか？
		return false;												// なければそのまま
	} else {
		timer = setTimeout( "go_link()", 500 );		// 有った場合、時間差でスクロール
		return false;	
	}
}
function go_link() {
	var jump_for = location.href.split( "?" )[ 1 ];
	var target = $( "#" + jump_for );
	var position = $( target ).offset().top;
	var scrHgt = document.body.scrollHeight;
	var cliHgt = document.documentElement.clientHeight;
	if ( position > scrHgt - cliHgt ){ position = scrHgt - cliHgt; }
	$( 'html, body' ).animate( { scrollTop:position }, 500, 'swing' );
}