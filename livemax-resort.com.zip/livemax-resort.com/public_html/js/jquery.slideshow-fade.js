﻿$(function(){
// 設定
var $width =2000; // 横幅
var $height =500; // 高さ
var $interval = 4000; // 切り替わりの間隔（ミリ秒）
var $fade_speed = 1500; // フェード処理の早さ（ミリ秒）
$("#slider ul li").css({"position":"relative","overflow":"hidden","width":$width,"height":$height});
$("#slider ul li").hide().css({"position":"absolute","top":0,"left":0});
$("#slider ul li:first").addClass("active").show();
setInterval(function(){
var $active = $("#slider ul li.active");
var $next = $active.next("li").length?$active.next("li"):$("#slider ul li:first");
$active.fadeOut($fade_speed).removeClass("active");
$next.fadeIn($fade_speed).addClass("active");
},$interval);
});

$(function(){
// 設定
var $width =960; // 横幅
var $height =450; // 高さ
var $interval = 4000; // 切り替わりの間隔（ミリ秒）
var $fade_speed = 1500; // フェード処理の早さ（ミリ秒）
$("#kokuchi_slider ul li").css({"position":"relative","overflow":"hidden","width":$width,"height":$height});
$("#kokuchi_slider ul li").hide().css({"position":"absolute","top":0,"left":0});
$("#kokuchi_slider ul li:first").addClass("active").show();
setInterval(function(){
var $active = $("#kokuchi_slider ul li.active");
var $next = $active.next("li").length?$active.next("li"):$("#kokuchi_slider ul li:first");
$active.fadeOut($fade_speed).removeClass("active");
$next.fadeIn($fade_speed).addClass("active");
},$interval);
});

$(function(){
// 設定
var $width =690; // 横幅
var $height =360; // 高さ
var $interval = 4000; // 切り替わりの間隔（ミリ秒）
var $fade_speed = 1500; // フェード処理の早さ（ミリ秒）
$(".sub_slider ul li").css({"position":"relative","overflow":"hidden","width":$width,"height":$height});
$(".sub_slider ul li").hide().css({"position":"absolute","top":0,"left":0});
$(".sub_slider ul li:first").addClass("active").show();
setInterval(function(){
var $active = $(".sub_slider ul li.active");
var $next = $active.next("li").length?$active.next("li"):$(".sub_slider ul li:first");
$active.fadeOut($fade_speed).removeClass("active");
$next.fadeIn($fade_speed).addClass("active");
},$interval);
});