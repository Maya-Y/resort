$(function(){
	  $("#thum0 a.room_img").click(function(){
			 $("#photo0 img").before("<img src='"+$(this).attr("href")+"' alt=''>");
			 $("#photo0 img:last").fadeOut("fast",function(){
						$(this).remove();
					});
			
			 return false;
	 });
});

$(function(){
	  $("#thum1 a.room_img").click(function(){
			 $("#photo1 img").before("<img src='"+$(this).attr("href")+"' alt=''>");
			 $("#photo1 img:last").fadeOut("fast",function(){
						$(this).remove();
					});
			
			 return false;
	 });
});

$(function(){
	  $("#thum2 a.room_img").click(function(){
			 $("#photo2 img").before("<img src='"+$(this).attr("href")+"' alt=''>");
			 $("#photo2 img:last").fadeOut("fast",function(){
						$(this).remove();
					});
			
			 return false;
	 });
});

$(function(){
	  $("#thum3 a.room_img").click(function(){
			 $("#photo3 img").before("<img src='"+$(this).attr("href")+"' alt=''>");
			 $("#photo3 img:last").fadeOut("fast",function(){
						$(this).remove();
					});
			
			 return false;
	 });
});

$(function(){
	  $("#thum4 a.room_img").click(function(){
			 $("#photo4 img").before("<img src='"+$(this).attr("href")+"' alt=''>");
			 $("#photo4 img:last").fadeOut("fast",function(){
						$(this).remove();
					});
			
			 return false;
	 });
});

$(function(){
	  $("#thum5 a.room_img").click(function(){
			 $("#photo5 img").before("<img src='"+$(this).attr("href")+"' alt=''>");
			 $("#photo5 img:last").fadeOut("fast",function(){
						$(this).remove();
					});
			
			 return false;
	 });
});

$(function(){
	  $("#thum6 a.room_img").click(function(){
			 $("#photo6 img").before("<img src='"+$(this).attr("href")+"' alt=''>");
			 $("#photo6 img:last").fadeOut("fast",function(){
						$(this).remove();
					});
			
			 return false;
	 });
});

$(function(){
	  $("#thum7 a.room_img").click(function(){
			 $("#photo7 img").before("<img src='"+$(this).attr("href")+"' alt=''>");
			 $("#photo7 img:last").fadeOut("fast",function(){
						$(this).remove();
					});
			
			 return false;
	 });
});

$(function(){
	  $("#thum8 a.room_img").click(function(){
			 $("#photo8 img").before("<img src='"+$(this).attr("href")+"' alt=''>");
			 $("#photo8 img:last").fadeOut("fast",function(){
						$(this).remove();
					});
			
			 return false;
	 });
});

$(function(){
	  $("#thum9 a.room_img").click(function(){
			 $("#photo9 img").before("<img src='"+$(this).attr("href")+"' alt=''>");
			 $("#photo9 img:last").fadeOut("fast",function(){
						$(this).remove();
					});
			
			 return false;
	 });
});

$(function(){
	  $("#thum10 a.room_img").click(function(){
			 $("#photo10 img").before("<img src='"+$(this).attr("href")+"' alt=''>");
			 $("#photo10 img:last").fadeOut("fast",function(){
						$(this).remove();
					});
			
			 return false;
	 });
});

$(function(){
	  $("#thum11 a.room_img").click(function(){
			 $("#photo11 img").before("<img src='"+$(this).attr("href")+"' alt=''>");
			 $("#photo11 img:last").fadeOut("fast",function(){
						$(this).remove();
					});
			
			 return false;
	 });
});

$(function(){
	  $("#thum12 a.room_img").click(function(){
			 $("#photo12 img").before("<img src='"+$(this).attr("href")+"' alt=''>");
			 $("#photo12 img:last").fadeOut("fast",function(){
						$(this).remove();
					});
			
			 return false;
	 });
});

$(function(){
	  $("#thum13 a.room_img").click(function(){
			 $("#photo13 img").before("<img src='"+$(this).attr("href")+"' alt=''>");
			 $("#photo13 img:last").fadeOut("fast",function(){
						$(this).remove();
					});
			
			 return false;
	 });
});

$(function(){
	  $("#thum14 a.room_img").click(function(){
			 $("#photo14 img").before("<img src='"+$(this).attr("href")+"' alt=''>");
			 $("#photo14 img:last").fadeOut("fast",function(){
						$(this).remove();
					});
			
			 return false;
	 });
});

$(function(){
	  $("#thum15 a.room_img").click(function(){
			 $("#photo15 img").before("<img src='"+$(this).attr("href")+"' alt=''>");
			 $("#photo15 img:last").fadeOut("fast",function(){
						$(this).remove();
					});
			
			 return false;
	 });
});
