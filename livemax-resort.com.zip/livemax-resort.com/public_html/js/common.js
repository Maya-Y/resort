<!--▼サイドメニューのトリップアドバイザー口コミ開閉枠-->
$(function(){
	$("#ta_widget").slideUp(0);//初期状態：「閉」
	$("#ta_widget_switch").click(function(){
		$("#ta_widget:not(:animated)").slideToggle("fast");
	});
});
<!--▲サイドメニューのトリップアドバイザー口コミ開閉枠-->